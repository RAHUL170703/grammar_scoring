#define JULIUS_PRODUCTNAME ""
#define JULIUS_VERSION "4.6"
#define JULIUS_SETUP "fast"
#define JULIUS_HOSTINFO ""
#define JULIUS_BUILD_INFO ""
#define RETSIGTYPE void
#define HAVE_PTHREAD 1
#define UNIGRAM_FACTORING 1
#define LOWMEM2 1
#define PASS1_IWCD 1
#define SCAN_BEAM 1
#define GPRUNE_DEFAULT_BEAM 1
#define CONFIDENCE_MEASURE 1
#define LM_FIX_DOUBLE_SCORING 1
#define GRAPHOUT_DYNAMIC 1
#define GRAPHOUT_SEARCH 1
/* Define if you have libfvad under this dir and enable it */
#define HAVE_LIBFVAD
